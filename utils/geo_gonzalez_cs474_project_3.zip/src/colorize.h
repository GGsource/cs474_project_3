#include "CustomString.h"
CustomString colorText(const char *c, const char *color);
CustomString colorText(CustomString const &c, const char *color);